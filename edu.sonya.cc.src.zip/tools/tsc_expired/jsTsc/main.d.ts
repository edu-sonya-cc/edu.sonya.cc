/// <reference path="../../../src/types/const.d.ts" />
/// <reference path="../../../src/types/dom.d.ts" />
/// <reference path="../../../src/types/data.d.ts" />
/// <reference path="../../../src/types/pcGlobal.d.ts" />
