var BrickCore = /** @class */ (function (_super) {
  __extends(BrickCore, _super);
  function BrickCore() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  return BrickCore;
}(CopybookBase));
var brickCore = new BrickCore();
window.brickCore = brickCore;
