/// <reference path="../../src/types/utils.d.ts" />
declare const diceGenerator: any;
declare const DiceKind: any;
declare const body: any;
declare let svgId: number;
