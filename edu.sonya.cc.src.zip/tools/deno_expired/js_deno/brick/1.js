// deno-fmt-ignore-file
// deno-lint-ignore-file
// This code was bundled using `deno bundle` and it's not recommended to edit it manually

class BrickCore extends CopybookBase {
}
const brickCore = new BrickCore();
window.brickCore = brickCore;
