// import { CopybookBase } from './copybookBase.ts';
// import { IBrickCore } from '../actualPage/IBrickCore.ts';
// import { I18nable, createElement, getI18nInnerHTML, getElementById, getTitleElement } from '../dom.ts';
// import { getCurrentLang, getCurrentPageLocalStorage, setCurrentPageLocalStorage } from '../storage.ts';
// import { DOMAIN, FILENAME_POSTFIX } from '../const.ts';

/// <reference path='../../types/copybookBase.d.ts' />
/// <reference path='../../types/IBrickCore.d.ts' />

class BrickCore extends CopybookBase {
  // constructor() {
  //   super({
  //    }, {
  //    }
  //  );
  // }
}

const brickCore = new BrickCore();
(window as unknown as { brickCore: IBrickCore }).brickCore = brickCore;
