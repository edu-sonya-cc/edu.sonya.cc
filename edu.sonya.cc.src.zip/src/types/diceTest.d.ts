declare const diceGenerator: edu.sonya.cc.DiceGenerator;
declare const DiceKind: typeof edu.sonya.cc.DiceKind;
declare const body: any;
declare let svgId: number;
